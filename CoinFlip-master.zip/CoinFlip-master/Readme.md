CoinFlip
==========

A simple Flip-a-Coin app for Jolla Sailfish.

Written when I realized a native version of this very important app (How else would one make
IMPORTANT DECISIONS) is still not available! This is my first forray into the world of Sailfish
app development.

Usage: To decide between IMPORTANT CHOICE A and IMPORTANT CHOICE B, simply say "If I flip a
heads, I will pick IMPORTANT CHOICE A, else I will pick IMPORTANT CHOICE B". Then select
"Flip!" from the pulley menu and watch your device decide your life!

It's also possible to flip for new results from the app Cover, though I'm not sure how
useful that'd be.

Code license is GPLv3 and BSD for the parts modified from Jolla's app template.

Heads/Tails coin images are public domain:
  - http://en.wikipedia.org/wiki/File:Presidential_$1_Reverse.png
  - http://en.wikipedia.org/wiki/File:George_Washington_Presidential_$1_Coin_obverse.png

App icon license: http://creativecommons.org/licenses/by-sa/3.0/