<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>CoverPage</name>
    <message>
        <source>Flip</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstPage</name>
    <message>
        <source>FLIP!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rolling..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You rolled </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip a Coin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use the pulley menu to flip!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CoinFlip 1.0.1
by Lim Yuen Hoe (Jason moofang)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>harbour-coinflip</name>
    <message>
        <source>Heads!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tails!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
